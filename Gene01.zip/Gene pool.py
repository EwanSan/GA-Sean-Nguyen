class Individual:
    def __init__(self,gen_code):
        self.gen_code=sorted(gen_code)
        self.fitness=0
        
        
    def getFitness(self):
        return self.fitness
        
    def getLen(self):
        return len(self.gen_code)
        
        
        
        
        
        
class Population:
    def __init__(self,ListOfIndividuals):
        self.ListOfIndividuals=ListOfIndividuals
        
#trier le code genetic


def crossover_individuals(a,b): # melanger le code génétique sans qu'il y ait de répetitions et sans 
    n=a.getLen()

    if a.gen_code(n//2)>b.gen_code(n//2):
        a,b=b,a
        
    child = Individual([])
       
    split = n//2
    child.gen_code = a.gen_code[0:split] + b.gen_code[split:-1]
    Population.ListOfIndividuals.append(child)
    return child.gen_code
    
    
        
 
    
    
    
    
    

def fitness(List): #écart à 0 
    for individual in   List:
        individual.fitness=sum(individual.gen_code)
        

def select_individuals(list):
    list = sorted(list, key=lambda list: list.fitness, reverse=True) #trier les individuals
    
    
a=Individual([1,2,3,4])
b=Individual([5,6,7,8])    
crossover_individuals(a,b)